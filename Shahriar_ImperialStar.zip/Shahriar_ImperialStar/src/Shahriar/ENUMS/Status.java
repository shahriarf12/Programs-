/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Shahriar.ENUMS;

/**
 *
 * @author Fahim
 */
public enum Status {
    READY,
    READYING,
    NOT_READY
}
