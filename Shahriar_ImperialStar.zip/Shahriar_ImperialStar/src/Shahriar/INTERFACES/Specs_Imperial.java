/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Shahriar.INTERFACES;

/**
 *
 * @author Fahim
 */
public interface Specs_Imperial {
	public static int[] hullSpecs_I = {900, 700, 100, 200, 75, 325, 350, 550};
	public static int[] hullSpecs_II = {900, 900, 100, 275, 200, 300, 400, 700};
	public static int[] deckSpecs_I = {150, 300, 600, 20, 30, 50, 100, 250, 400, 75, 125, 250};
	public static int[] deckSpecs_II = {200, 350, 700, 22, 34, 56, 150, 300, 450, 100, 150, 300};
	public static int[] engineSpecs_I = {100, 225, 50, 75, 800000, 15000000, 100, 125};
	public static int[] engineSpecs_II = {115, 275, 60, 80, 9000000, 17000000, 100, 125};

}
