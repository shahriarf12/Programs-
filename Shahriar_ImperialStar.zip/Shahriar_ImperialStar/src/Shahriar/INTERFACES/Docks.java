/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Shahriar.INTERFACES;

/**
 *
 * @author Fahim
 */
public interface Docks {
    public boolean docks(String D);
    public boolean undocks(String D);
}
