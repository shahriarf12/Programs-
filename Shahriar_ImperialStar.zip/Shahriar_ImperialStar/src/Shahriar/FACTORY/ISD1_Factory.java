/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shahriar.FACTORY;

/**
 *
 * @author Fahim
 */
public class ISD1_Factory {
    private String buildType = "Imperial I";
    
    public ISD1_Factory(String name){
        
    }
    
    public boolean buildISDs(int count){
        return true; 
    }
    
    public void displayISDs(int count){
        
    }
}
