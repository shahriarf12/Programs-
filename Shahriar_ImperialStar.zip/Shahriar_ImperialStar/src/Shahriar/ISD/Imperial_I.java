/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Shahriar.ISD;

/**
 *
 * @author Fahim
 */
public class Imperial_I extends StarDestroyer {
    
    public Imperial_I(String ShpNumber, String ShpName){
        super(ShpNumber, ShpName, "Imperial_I");
    }
    
    public void navigatesToPosition(String p) {
        System.out.println("Navigating to Position " + p);	
    }
    
    public void displayImperial_I(){
        
    }
}
