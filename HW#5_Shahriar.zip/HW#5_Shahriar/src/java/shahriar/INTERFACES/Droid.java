
package shahriar.INTERFACES;


public interface Droid {
    public abstract void displayDroid();
}
