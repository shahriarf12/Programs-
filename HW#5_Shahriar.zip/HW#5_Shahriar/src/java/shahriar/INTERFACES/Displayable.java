
package shahriar.INTERFACES;


public interface Displayable {
    public abstract void displayAllDroids();
}
