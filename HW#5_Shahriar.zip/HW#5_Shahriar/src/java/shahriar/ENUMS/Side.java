
package shahriar.ENUMS;

public enum Side {
    LEFT,RIGHT
}
