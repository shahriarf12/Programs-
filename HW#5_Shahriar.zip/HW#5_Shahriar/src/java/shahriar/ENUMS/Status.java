
package shahriar.ENUMS;


public enum Status {
    ONLINE,OFFLINE
}
